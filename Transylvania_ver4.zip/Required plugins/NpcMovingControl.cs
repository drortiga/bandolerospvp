using Newtonsoft.Json;
using CompanionServer.Handlers;
using UnityEngine;
using UnityEngine.AI;
using System;
using System.Collections.Generic;
using Oxide.Core;
using Oxide.Core.Plugins;
using Oxide.Plugins.NpcMovingControlExtensionMethods;

namespace Oxide.Plugins
{
    [Info("NpcMovingControl", "Adem", "1.0.0")]
    class NpcMovingControl : RustPlugin
    {
        #region Variables
        [PluginReference] private Plugin BotReSpawn;
        HashSet<string> subscribeMethods = new HashSet<string>
        {
            "OnEntitySpawned",
        };
        #endregion Variables

        #region Hooks
        void Init()
        {
            Unsubscribes();
        }

        void OnServerInitialized()
        {
            Subscribes();
            UpdateAllNpc();
        }

        void OnEntitySpawned(ScarecrowNPC scarecrowNPC)
        {
            if (scarecrowNPC == null)
                return;

            if (_config.scarecrowPatrolRadius > -1)
            {
                scarecrowNPC.RoamAroundHomePoint = true;

                if (_config.scarecrowPatrolRadius > 0)
                { 
                    NextTick(() =>
                    {
                        if (scarecrowNPC != null && scarecrowNPC.Brain != null)
                            scarecrowNPC.Brain.Navigator.BestCoverPointMaxDistance = _config.scarecrowPatrolRadius;
                    });
                }
            }
        }

        void OnEntitySpawned(ScientistNPC scientistNPC)
        {
            if(scientistNPC != null)
                UpdateNpc(scientistNPC);
        }
        #endregion Hooks

        #region Methods
        void Unsubscribes()
        {
            foreach (string hook in subscribeMethods)
                Unsubscribe(hook);
        }

        void Subscribes()
        {
            foreach (string hook in subscribeMethods)
                Subscribe(hook);
        }

        void UpdateAllNpc()
        {
            foreach (ScientistNPC scientistNPC in BaseNetworkable.serverEntities.OfType<ScientistNPC>())
                if (scientistNPC != null)
                    UpdateNpc(scientistNPC);
        }

        void UpdateNpc(ScientistNPC scientistNPC)
        {
            TryWearNpc(scientistNPC);

            if (scientistNPC.ShortPrefabName == "scientistnpc_roam" && _config.npcPatrolRadius > 0)
                timer.In(2f, () => TryModifyNpc(scientistNPC));
        }

        void TryWearNpc(ScientistNPC scientistNPC)
        {
            CustomNpcWearConfig customNpcWearConfig = _config.customNpcWearConfigs.FirstOrDefault(x => x.npcShortPrefabName == scientistNPC.ShortPrefabName);
            
            if (customNpcWearConfig != null)
            {
                WearConfig wearConfig = customNpcWearConfig.wearConfigs.GetRandom();

                if (wearConfig != null)
                    ApplyWearConfigToNpc(scientistNPC, wearConfig);
            }
        }

        void ApplyWearConfigToNpc(ScientistNPC scientistNPC, WearConfig wearConfig)
        {
            scientistNPC.inventory.containerWear.ClearItemsContainer();

            foreach (WearItemConfig wearItemConfig in wearConfig.wearItems)
            {
                Item item = ItemManager.CreateByName(wearItemConfig.shortName, skin: wearItemConfig.skinID);
                
                if (item != null)
                    item.MoveToContainer(scientistNPC.inventory.containerWear);
            }
        }

        void TryModifyNpc(ScientistNPC scientistNPC)
        {
            if (scientistNPC == null || scientistNPC.Brain == null || scientistNPC.isMounted)
                return;

            if (scientistNPC.GetType().ToString() != "ScientistNPC" || scientistNPC.Brain.GetType().ToString() != "ScientistBrain")
                return;

            if (plugins.Exists("BotReSpawn") && (bool)BotReSpawn?.Call("IsBotReSpawn", scientistNPC.userID))
                return;

            if (scientistNPC.Brain.states.ContainsKey(AIState.FollowPath))
            {
                scientistNPC.Brain.states[AIState.Roam] = new RoamState(scientistNPC.transform.position, _config.npcPatrolRadius, scientistNPC);

                scientistNPC.Brain.CurrentState.StateLeave(scientistNPC.Brain, scientistNPC);
                scientistNPC.Brain.states.Remove(AIState.FollowPath);

                scientistNPC.Brain.CurrentState = scientistNPC.Brain.states[AIState.Roam];
                scientistNPC.Brain.CurrentState?.StateEnter(scientistNPC.Brain, scientistNPC);
            }
        }
        #endregion Methods

        #region Classes
        class RoamState : BaseAIBrain.BasicAIState
        {
            ScientistNPC scientistNPC;
            Vector3 roamPosition;
            float roamRadius;
            
            internal RoamState(Vector3 roamPosition, float roamRadius, ScientistNPC scientistNPC) : base(AIState.Roam) 
            { 
                this.roamPosition = roamPosition;
                this.roamRadius = roamRadius;
                this.scientistNPC = scientistNPC;
            }

            public override StateStatus StateThink(float delta, BaseAIBrain brain, BaseEntity entity)
            {
                base.StateThink(delta, brain, entity);
                float distanceFromPatrolCenter = Vector3.Distance(scientistNPC.transform.position, roamPosition);
                
                if (distanceFromPatrolCenter > roamRadius)
                {
                    Vector3 roamPositionOnNavmesh = GetPositionOnNavmesh(roamPosition, 3);
                    NpcRoamToPosition(roamPositionOnNavmesh);
                }
                else if (!brain.Navigator.Moving)
                {
                    Vector3 randomRoamPosition = GetRandomRoamPosition(roamPosition);
                    randomRoamPosition = GetPositionOnNavmesh(randomRoamPosition, 3);
                    NpcRoamToPosition(randomRoamPosition);
                }
                   
                return StateStatus.Running;
            }

            Vector3 GetRandomRoamPosition(Vector3 source)
            {
                Vector2 vector2 = UnityEngine.Random.insideUnitCircle * roamRadius;
                return source + new Vector3(vector2.x, 0f, vector2.y);
            }

            void NpcRoamToPosition(Vector3 position)
            {
                Vector3 currentDestination = scientistNPC.Brain.Navigator.Destination;

                if (Vector3.Distance(currentDestination, position) < 0.1f)
                    return;

                scientistNPC.Brain.Navigator.SetDestination(position, BaseNavigator.NavigationSpeed.Slow);
            }

            Vector3 GetPositionOnNavmesh(Vector3 position, float radius)
            {
                NavMeshHit navMeshHit;
                if (NavMesh.SamplePosition(position, out navMeshHit, radius, scientistNPC.NavAgent.areaMask))
                {
                    NavMeshPath path = new NavMeshPath();

                    if (NavMesh.CalculatePath(scientistNPC.transform.position, navMeshHit.position, scientistNPC.NavAgent.areaMask, path))
                    {
                        if (path.status == NavMeshPathStatus.PathComplete) 
                            return navMeshHit.position;
                        else 
                            return path.corners.Last();
                    }
                }
                return position;
            }
        }
        #endregion Classes

        #region Config 
        private PluginConfig _config;

        protected override void LoadDefaultConfig()
        {
            _config = PluginConfig.DefaultConfig();
        }

        protected override void LoadConfig()
        {
            base.LoadConfig();
            _config = Config.ReadObject<PluginConfig>();
            Config.WriteObject(_config, true);
        }

        protected override void SaveConfig()
        {
            Config.WriteObject(_config);
        }

        public class CustomNpcWearConfig
        {
            [JsonProperty("Npc ShortPrefabName")] public string npcShortPrefabName { get; set; }
            [JsonProperty("Replace clothes for this preset?")] public bool enable { get; set; }
            [JsonProperty("Random Clothing presets")] public List<WearConfig> wearConfigs { get; set; }
        }

        public class WearConfig
        {
            [JsonProperty("List of items:")] public HashSet<WearItemConfig> wearItems { get; set; }
        }

        public class WearItemConfig
        {
            [JsonProperty("ShortName")] public string shortName { get; set; }
            [JsonProperty("skinID (0 - default)")] public ulong skinID { get; set; }
        }

        private class PluginConfig
        {
            [JsonProperty("Version")] public VersionNumber version { get; set; }
            [JsonProperty("NPC patrol Radius (-1 - Do not change the behavior; 0 - Do not change the radius)")] public float npcPatrolRadius { get; set; }
            [JsonProperty("Scarecrow patrol Radius (-1 - Do not change the behavior)")] public float scarecrowPatrolRadius { get; set; }
            [JsonProperty("Configuring the replacement of NPC clothes")] public HashSet<CustomNpcWearConfig> customNpcWearConfigs { get; set; }

            public static PluginConfig DefaultConfig()
            {
                PluginConfig pluginConfig = new PluginConfig()
                {
                    version = new VersionNumber(1, 0, 0),
                    npcPatrolRadius = 20,
                    scarecrowPatrolRadius = 0,

                    customNpcWearConfigs =  new HashSet<CustomNpcWearConfig>
                    {
                        new CustomNpcWearConfig
                        {
                            npcShortPrefabName = "scientistnpc_roam",
                            enable = true,
                            wearConfigs = new List<WearConfig>
                            {
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "jumpsuit.suit.blue",
                                            skinID = 0,
                                        },
                                        new WearItemConfig
                                        {
                                            shortName = "shoes.boots",
                                            skinID = 0,
                                        },
                                        new WearItemConfig
                                        {
                                            shortName = "hat.beenie",
                                            skinID = 0,
                                        },
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "jumpsuit.suit",
                                            skinID = 0,
                                        },
                                        new WearItemConfig
                                        {
                                            shortName = "shoes.boots",
                                            skinID = 0,
                                        },
                                        new WearItemConfig
                                        {
                                            shortName = "mask.bandana",
                                            skinID = 0,
                                        },
                                        new WearItemConfig
                                        {
                                            shortName = "hat.cap",
                                            skinID = 0,
                                        },
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "halloween.surgeonsuit",
                                            skinID = 0,
                                        }
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "halloween.surgeonsuit",
                                            skinID = 0,
                                        }
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "hazmatsuit.arcticsuit",
                                            skinID = 0,
                                        }
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "hazmatsuit_scientist_nvgm",
                                            skinID = 0,
                                        }
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "hazmatsuit_scientist_peacekeeper",
                                            skinID = 0,
                                        }
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "hazmatsuit_scientist_arctic",
                                            skinID = 0,
                                        }
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "attire.banditguard",
                                            skinID = 0,
                                        }
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "hazmatsuit.nomadsuit",
                                            skinID = 0,
                                        }
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "hazmatsuit.lumberjack",
                                            skinID = 0,
                                        }
                                    }
                                },
                                new WearConfig
                                {
                                    wearItems =  new HashSet<WearItemConfig>
                                    {
                                        new WearItemConfig
                                        {
                                            shortName = "hazmatsuit.diver",
                                            skinID = 0,
                                        }
                                    }
                                }
                            }
                        }
                    }

                };
                return pluginConfig;
            }
        }
        #endregion Config
    }
}

namespace Oxide.Plugins.NpcMovingControlExtensionMethods
{
    public static class ExtensionMethods
    {
        public static TSource Last<TSource>(this IList<TSource> source) => source[source.Count - 1];

        public static void ClearItemsContainer(this ItemContainer container)
        {
            for (int i = container.itemList.Count - 1; i >= 0; i--)
            {
                Item item = container.itemList[i];
                item.RemoveFromContainer();
                item.Remove();
            }
        }

        public static TSource FirstOrDefault<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicate)
        {
            using (var enumerator = source.GetEnumerator()) while (enumerator.MoveNext()) if (predicate(enumerator.Current)) return enumerator.Current;
            return default(TSource);
        }

        public static HashSet<T> OfType<T>(this IEnumerable<BaseNetworkable> source)
        {
            HashSet<T> result = new HashSet<T>();
            using (var enumerator = source.GetEnumerator()) while (enumerator.MoveNext()) if (enumerator.Current is T) result.Add((T)(object)enumerator.Current);
            return result;
        }
    }
}